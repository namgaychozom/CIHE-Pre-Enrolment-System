# Frontend
Contains UI/UX files, HTML/CSS/JS code, or visual Studio front-end code for the project.
